class DataMod {
  final id;
  final city_name;
  final city_image;
  final description;
  DataMod(this.id, this.city_name, this.city_image, this.description);
}
