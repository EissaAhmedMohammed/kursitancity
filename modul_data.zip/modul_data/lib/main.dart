import 'package:flutter/material.dart';
import 'package:modul_data/src/homeListview.dart';

void main() {
  runApp(const KurdistanCities());
}
